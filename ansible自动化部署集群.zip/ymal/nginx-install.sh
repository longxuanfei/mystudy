#!/bin/bash
useradd -s /sbin/nologin -M nginx
yum install gcc gcc-c++ -y
yum install pcre-devel -y
yum install openssl-devel -y
wget https://nginx.org/download/nginx-1.27.4.tar.gz
tar -xvf nginx-1.27.4.tar.gz -C /usr/local/src
cd /usr/local/src/nginx-1.27.4/
./configure --user=nginx --group=nginx --prefix=/usr/local/nginx --with-http_stub_status_module --with-http_sub_module --with-http_ssl_module --with-http_realip_module --with-pcre >> /dev/null
make&&make install >> /dev/null
